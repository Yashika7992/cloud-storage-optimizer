import boto3
from datetime import datetime, timezone, timedelta

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('storage-resources')

def lambda_handler(event, context):
    try:
        response = table.scan()
        items = response.get('Items', [])

        now = datetime.now(timezone.utc)

        for item in items:
            resource_id = item['resource_id']
            last_accessed = item.get('last_accessed')

            # Default status
            status = "ACTIVE"

            if last_accessed:
                last_accessed_date = datetime.fromisoformat(last_accessed)
                days_unused = (now - last_accessed_date).days

                if days_unused > 90:
                    status = "DELETE_CANDIDATE"
                elif days_unused > 30:
                    status = "UNUSED"

            # Update DynamoDB
            table.update_item(
                Key={'resource_id': resource_id},
                UpdateExpression="SET #s = :s",
                ExpressionAttributeNames={'#s': 'status'},
                ExpressionAttributeValues={':s': status}
            )

        return {
            "statusCode": 200,
            "body": "Analysis completed"
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "error": str(e)
        }